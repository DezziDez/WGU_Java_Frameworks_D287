A: Repo cloned, working_branch created.

B: README started.

C: UI Changes made in mainscreen.html, Lines: 14 and 19

D: Added about page buttom in mainscreen.html, Line: 89. Created AboutController to handle button input.

E: Added Inventory BootStrapData 71 - 146 (most of the page)

F: Added buy now button. 
Lines/files: 
mainscreen.html : 85,86
AddProductController : 110-134
confirmationbuyproduct.html created

G: Modified the parts to track maximum and minimum inventory
application.properties - 6
mainscreen.html - 48, 49
inhousePartForm.html 24, 26, 30-34
Part class: 34-37, 52, 53
OutsourcedPartForm.html 30-35

G/H: Add validation for between or at the maximum and minimum fields.
Modified EnufPartsValidator 36
Created ValidMinMaxPart
Created MinMaxPartValidator

I: Add at least two unit tests for the maximum and minimum fields to the PartTest class in the test package.
PartTest Class - 104-121

J: Remove the class files for any unused validators in order to clean your code.
All Classes in use or to be used when parts or products are modified.