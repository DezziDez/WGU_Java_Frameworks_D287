package com.example.demo.bootstrap;

import com.example.demo.domain.InhousePart;
import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.InhousePartRepository;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.OutsourcedPartService;
import com.example.demo.service.OutsourcedPartServiceImpl;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;

    private final OutsourcedPartRepository outsourcedPartRepository;

    private final InhousePartRepository inhousePartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository, InhousePartRepository inhousePartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository=outsourcedPartRepository;
        this.inhousePartRepository=inhousePartRepository;
    }
    @Override

    public void run(String... args) throws Exception {

       /*
        OutsourcedPart o= new OutsourcedPart();
        o.setCompanyName("Western Governors University");
        o.setName("out test");
        o.setInv(5);
        o.setPrice(20.0);
        o.setId(100L);
        outsourcedPartRepository.save(o);
        OutsourcedPart thePart=null;
        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            if(part.getName().equals("out test"))thePart=part;
        }

        System.out.println(thePart.getCompanyName());
        */
        List<OutsourcedPart> outsourcedParts = (List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for (OutsourcedPart part : outsourcedParts) {
            System.out.println(part.getName() + " " + part.getCompanyName());
        }

        // Checks to see if an in house part with that ID exists. And if it does not, it is created on startup.
        InhousePart TTB = new InhousePart();
        TTB.setName("Twin Tip Blank");
        TTB.setInv(3);
        TTB.setPrice(100.0);
        TTB.setId(1);
        TTB.setMaxinv(100);

        InhousePart PTB = new InhousePart();
        PTB.setName("Pintail Blank");
        PTB.setInv(5);
        PTB.setPrice(100.0);
        PTB.setId(2);
        PTB.setMaxinv(100);

        InhousePart OSB = new InhousePart();
        OSB.setName("Old School Blank");
        OSB.setInv(10);
        OSB.setPrice(75.0);
        OSB.setId(3);
        OSB.setMaxinv(100);

        InhousePart DTB = new InhousePart();
        DTB.setName("Drop Through Blank");
        DTB.setInv(3);
        DTB.setPrice(100.0);
        DTB.setId(4);
        DTB.setMaxinv(100);

        InhousePart SB = new InhousePart();
        SB.setName("Standard Blank");
        SB.setInv(3);
        SB.setPrice(50.0);
        SB.setId(5);
        SB.setMaxinv(100);

        OutsourcedPart LBW = new OutsourcedPart();
        LBW.setCompanyName("Wheel Pro");
        LBW.setName("Long-board Wheels (Set of 4)");
        LBW.setInv(20);
        LBW.setPrice(20.0);
        LBW.setId(101);
        LBW.setMaxinv(100);

        OutsourcedPart SBW = new OutsourcedPart();
        SBW.setCompanyName("Wheel Pro");
        SBW.setName("Short-board Wheels (Set of 4)");
        SBW.setInv(30);
        SBW.setPrice(20.0);
        SBW.setId(102);
        SBW.setMaxinv(100);

        List<Part> PartList=(List<Part>) partRepository.findAll();
        if(PartList.isEmpty()){
            inhousePartRepository.save(TTB);
            inhousePartRepository.save(PTB);
            inhousePartRepository.save(OSB);
            inhousePartRepository.save(DTB);
            inhousePartRepository.save(SB);
            outsourcedPartRepository.save(LBW);
            outsourcedPartRepository.save(SBW);
        }

        // Checks to see if a product with that ID exists. And if it does not, it is created on startup.
        Product Pintail_Longboard = new Product(1,"Pintail Longboard", 350, 3);
        Product Old_School_Shortboard = new Product(2,"Old School Short-board", 150.0, 8);
        Product Drop_Through_Longboard = new Product(3, "Drop Through Long-board", 300.0, 7);
        Product Twin_Tip_Longboard = new Product(4, "Twin Tip Long-board", 300.0, 4);
        Product Standard_Shortboard = new Product(5, "Standard Short-board", 100.0, 10);

        List<Product> ProductList=(List<Product>) productRepository.findAll();
        if(ProductList.isEmpty()){
            productRepository.save(Pintail_Longboard);
            productRepository.save(Old_School_Shortboard);
            productRepository.save(Drop_Through_Longboard);
            productRepository.save(Twin_Tip_Longboard);
            productRepository.save(Standard_Shortboard);
        }

        System.out.println("Started in Bootstrap");
        System.out.println("Number of Products " + productRepository.count());
        System.out.println(productRepository.findAll());
        System.out.println("Number of Parts " + partRepository.count());
        System.out.println(partRepository.findAll());

    }
}
