package com.example.demo.validators;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *
 *
 *
 *
 */
@Constraint(validatedBy = {MinMaxPartValidator.class})
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidMinMaxPart {
    String message() default "The inventory of the part must be greater than or equal to the minimum inventory of the part and less than or equal to the maximum inventory of the part.";
    Class<?> [] groups() default {};
    Class<? extends Payload> [] payload() default {};
}
